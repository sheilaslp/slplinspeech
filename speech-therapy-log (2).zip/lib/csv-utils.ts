interface FormData {
  sound: string
  activity: string
  attempts: string
  correct: string
  notes: string
}

export function downloadCSV(data: FormData) {
  const attempts = Number.parseInt(data.attempts) || 0
  const correct = Number.parseInt(data.correct) || 0
  const accuracy = attempts > 0 ? Math.round((correct / attempts) * 100) : 0

  // Format the entry in the requested format
  const formattedEntry = `${data.sound} ${data.activity} ${accuracy}% (${correct}/${attempts}) ${data.notes}`

  const blob = new Blob([formattedEntry], { type: "text/plain;charset=utf-8;" })
  const url = URL.createObjectURL(blob)
  const link = document.createElement("a")

  link.setAttribute("href", url)
  link.setAttribute("download", `語音紀錄_artic_log.txt`)
  link.style.visibility = "hidden"

  document.body.appendChild(link)
  link.click()
  document.body.removeChild(link)
}
