import type { Metadata } from "next"
import ArticulationLogForm from "@/components/articulation-log-form"
import LanguageSwitch from "@/components/language-switch"

export const metadata: Metadata = {
  title: "語音治療紀錄表 | Speech Sound Log",
  description: "語言治療師臨床工具 | for Speech-Language Pathologists (SLP)",
}

export default function Home() {
  return (
    <main className="min-h-screen bg-[#f8f7e2]">
      <div className="container mx-auto px-4 py-8 max-w-2xl">
        <div className="bg-white rounded-lg shadow-lg p-6 md:p-8">
          <div className="flex justify-end mb-4">
            <LanguageSwitch />
          </div>

          <ArticulationLogForm />

          <div className="mt-8 pt-6 border-t border-gray-200">
            <p className="text-sm text-gray-600 mb-2 text-center">
              為確保資訊的準確性，我們強烈建議您先行檢查內容的正確性再使用於臨床紀錄中。
            </p>
            <p className="text-sm text-gray-500 text-center">Designed by Sheila Lin, MSc., reg. CASLPO, S-LP(C)</p>
          </div>
        </div>
      </div>
    </main>
  )
}
