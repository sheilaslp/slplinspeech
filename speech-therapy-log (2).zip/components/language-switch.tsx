"use client"

import { Button } from "@/components/ui/button"
import { Globe } from "lucide-react"
import { useLanguage } from "@/contexts/language-context"

export default function LanguageSwitch() {
  const { toggleLanguage, t } = useLanguage()

  return (
    <Button
      onClick={toggleLanguage}
      variant="outline"
      className="flex items-center gap-2 border-[#1e3163]/30 text-[#1e3163]"
    >
      <Globe className="h-4 w-4" />
      {t("button.switchLanguage")}
    </Button>
  )
}
