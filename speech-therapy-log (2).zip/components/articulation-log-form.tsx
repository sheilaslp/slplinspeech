"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Plus, Copy, Download } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import LogEntryForm, { type LogEntry } from "./log-entry-form"
import { useLanguage } from "@/contexts/language-context"

export default function ArticulationLogForm() {
  const [logEntries, setLogEntries] = useState<LogEntry[]>([])
  const [formBlocks, setFormBlocks] = useState<string[]>(["initial"])
  const { toast } = useToast()
  const { t } = useLanguage()

  // Load saved entries from localStorage
  useEffect(() => {
    const savedEntries = localStorage.getItem("logEntries")
    if (savedEntries) {
      try {
        setLogEntries(JSON.parse(savedEntries))
      } catch (e) {
        console.error("Failed to parse saved entries", e)
      }
    }
  }, [])

  // Save entries to localStorage when they change
  useEffect(() => {
    if (logEntries.length > 0) {
      localStorage.setItem("logEntries", JSON.stringify(logEntries))
    }
  }, [logEntries])

  const handleSaveEntry = (entry: LogEntry) => {
    setLogEntries((prev) => [...prev, entry])
    toast({
      title: "Entry saved",
      description: `Entry for ${entry.sound || "sound"} has been saved.`,
    })
  }

  const handleCopyToClipboard = () => {
    if (logEntries.length === 0) {
      toast({
        title: "No entries to copy",
        description: "Please log some entries first.",
        variant: "destructive",
      })
      return
    }

    // Format entries in the requested format
    const formattedEntries = logEntries
      .map((entry) => {
        const attempts = Number.parseInt(entry.attempts) || 0
        const correct = Number.parseInt(entry.correct) || 0
        const accuracy = attempts > 0 ? Math.round((correct / attempts) * 100) : 0

        return `${entry.sound} ${entry.activity} ${accuracy}% (${correct}/${attempts}) ${entry.notes}`
      })
      .join("\n")

    navigator.clipboard.writeText(formattedEntries).then(
      () => {
        toast({
          title: "Copied to clipboard",
          description: `${logEntries.length} entries copied to clipboard.`,
        })
      },
      (err) => {
        console.error("Could not copy text: ", err)
        toast({
          title: "Failed to copy",
          description: "Could not copy to clipboard. Please try again.",
          variant: "destructive",
        })
      },
    )
  }

  const handleDownloadAllEntries = () => {
    if (logEntries.length === 0) {
      toast({
        title: "No entries to download",
        description: "Please log some entries first.",
        variant: "destructive",
      })
      return
    }

    // Format entries in the requested format
    const formattedEntries = logEntries
      .map((entry) => {
        const attempts = Number.parseInt(entry.attempts) || 0
        const correct = Number.parseInt(entry.correct) || 0
        const accuracy = attempts > 0 ? Math.round((correct / attempts) * 100) : 0

        return `${entry.sound} ${entry.activity} ${accuracy}% (${correct}/${attempts}) ${entry.notes}`
      })
      .join("\n")

    const blob = new Blob([formattedEntries], { type: "text/plain;charset=utf-8;" })
    const url = URL.createObjectURL(blob)
    const link = document.createElement("a")
    link.setAttribute("href", url)
    link.setAttribute("download", `語音紀錄_all_entries.txt`)
    link.style.visibility = "hidden"
    document.body.appendChild(link)
    link.click()
    document.body.removeChild(link)
  }

  const addFormBlock = () => {
    setFormBlocks((prev) => [...prev, `block-${Date.now()}`])
  }

  const removeFormBlock = (id: string) => {
    setFormBlocks((prev) => prev.filter((blockId) => blockId !== id))
  }

  return (
    <div>
      <h1 className="text-2xl md:text-3xl font-bold text-center mb-6 text-[#1e3163]">
        {t("page.title")}
        <br />
        <span className="text-lg md:text-xl text-[#1e3163]/80">{t("page.subtitle")}</span>
      </h1>

      <div className="mb-6 flex flex-wrap gap-2">
        <Button onClick={handleCopyToClipboard} className="flex-1 bg-[#1e3163] hover:bg-[#1e3163]/90" variant="default">
          <Copy className="mr-2 h-4 w-4" />
          {t("button.copyLog")}
        </Button>
        <Button
          onClick={handleDownloadAllEntries}
          className="flex-1 bg-[#c74646] hover:bg-[#c74646]/90"
          variant="default"
        >
          <Download className="mr-2 h-4 w-4" />
          {t("button.downloadAll")}
        </Button>
      </div>

      {formBlocks.map((id, index) => (
        <LogEntryForm
          key={id}
          onSaveEntry={handleSaveEntry}
          onRemove={() => removeFormBlock(id)}
          isRemovable={index > 0}
        />
      ))}

      <Button onClick={addFormBlock} className="w-full bg-[#1e3163] hover:bg-[#1e3163]/90" variant="default">
        <Plus className="mr-2 h-4 w-4" />
        {t("button.addAnother")}
      </Button>
    </div>
  )
}
