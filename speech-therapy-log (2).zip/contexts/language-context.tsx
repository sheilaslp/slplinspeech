"use client"

import { createContext, useContext, useState, useEffect, type ReactNode } from "react"

type LanguageContextType = {
  language: "en" | "zh"
  toggleLanguage: () => void
  t: (key: string) => string
}

const translations = {
  en: {
    // Page title
    "page.title": "Speech Sound Log",
    "page.subtitle": "for Speech-Language Pathologists (SLP)",

    // Form labels
    "form.targetSound": "Target Sound",
    "form.playActivity": "Play Activity",
    "form.trials": "Number of Trials",
    "form.correct": "Number Correct",
    "form.notes": "Notes / Observations",

    // Buttons
    "button.logEntry": "Log Entry",
    "button.clearEntry": "Clear Entry",
    "button.downloadCSV": "Download CSV",
    "button.copyLog": "Copy Log to Clipboard",
    "button.downloadAll": "Download All Entries",
    "button.addAnother": "Add Another Sound Entry",
    "button.switchLanguage": "切換語言",
    "button.addActivity": "Add Custom Activity",
    "button.editActivity": "Edit Activity",
    "button.update": "Update",
    "button.add": "Add",

    // Placeholders
    "placeholder.selectSound": "Select sound",
    "placeholder.selectActivity": "Select activity",
    "placeholder.enterActivity": "Enter activity name",

    // Card titles
    "card.soundEntry": "Sound Entry",

    // Footer
    "footer.disclaimer":
      "To ensure accuracy, we strongly recommend verifying the content before using it in clinical records.",
    "footer.credit": "Designed by Sheila Lin, MSc., reg. CASLPO, S-LP(C)",
  },
  zh: {
    // Page title
    "page.title": "語音治療紀錄表",
    "page.subtitle": "語言治療師臨床工具",

    // Form labels
    "form.targetSound": "目標語音",
    "form.playActivity": "遊戲活動類型",
    "form.trials": "嘗試次數",
    "form.correct": "正確次數",
    "form.notes": "備註 / 觀察",

    // Buttons
    "button.logEntry": "紀錄",
    "button.clearEntry": "清除",
    "button.downloadCSV": "下載 CSV",
    "button.copyLog": "複製紀錄到剪貼簿",
    "button.downloadAll": "下載所有紀錄",
    "button.addAnother": "新增語音紀錄",
    "button.switchLanguage": "Switch to English",
    "button.addActivity": "新增活動",
    "button.editActivity": "編輯活動",
    "button.update": "更新",
    "button.add": "新增",

    // Placeholders
    "placeholder.selectSound": "選擇語音",
    "placeholder.selectActivity": "選擇活動",
    "placeholder.enterActivity": "輸入活動名稱",

    // Card titles
    "card.soundEntry": "語音紀錄",

    // Footer
    "footer.disclaimer": "為確保資訊的準確性，我們強烈建議您先行檢查內容的正確性再使用於臨床紀錄中。",
    "footer.credit": "Designed by Sheila Lin, MSc., reg. CASLPO, S-LP(C)",
  },
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined)

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<"en" | "zh">("en")

  // Load language preference from localStorage on component mount
  useEffect(() => {
    const savedLanguage = localStorage.getItem("preferredLanguage")
    if (savedLanguage === "en" || savedLanguage === "zh") {
      setLanguage(savedLanguage)
    }
  }, [])

  // Save language preference to localStorage whenever it changes
  useEffect(() => {
    localStorage.setItem("preferredLanguage", language)
  }, [language])

  const toggleLanguage = () => {
    setLanguage((prev) => (prev === "en" ? "zh" : "en"))
  }

  const t = (key: string): string => {
    return translations[language][key as keyof (typeof translations)[typeof language]] || key
  }

  return <LanguageContext.Provider value={{ language, toggleLanguage, t }}>{children}</LanguageContext.Provider>
}

export function useLanguage() {
  const context = useContext(LanguageContext)
  if (context === undefined) {
    throw new Error("useLanguage must be used within a LanguageProvider")
  }
  return context
}
