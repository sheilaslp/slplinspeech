"use client"

import type React from "react"
import { useState, useEffect } from "react"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { X, Plus, Pencil, Save, Trash2 } from "lucide-react"
import { downloadCSV } from "@/lib/csv-utils"
import { useLanguage } from "@/contexts/language-context"

// Base play activities sorted alphabetically by English name
const basePlayActivities = [
  { value: "Drawing/Coloring", label: "畫畫／著色 Drawing/Coloring" },
  { value: "Games", label: "遊戲 Games" },
  { value: "Joint Reading", label: "共讀 Joint Reading" },
  { value: "Other", label: "其他 Other" },
  { value: "Pretend Play", label: "扮家家酒 Pretend Play" },
  { value: "Puzzles", label: "拼圖 Puzzles" },
  { value: "Sensory Play", label: "感官遊戲 Sensory Play" },
  { value: "Toys", label: "玩具 Toys" },
]

const ipaSymbols = [
  // English Consonants
  { value: "/p/", label: "/p/ - pen" },
  { value: "/b/", label: "/b/ - bat" },
  { value: "/t/", label: "/t/ - top" },
  { value: "/d/", label: "/d/ - dog" },
  { value: "/k/", label: "/k/ - cat" },
  { value: "/g/", label: "/g/ - go" },
  { value: "/m/", label: "/m/ - man" },
  { value: "/n/", label: "/n/ - no" },
  { value: "/ŋ/", label: "/ŋ/ - sing" },
  { value: "/f/", label: "/f/ - fan" },
  { value: "/v/", label: "/v/ - van" },
  { value: "/θ/", label: "/θ/ - think" },
  { value: "/ð/", label: "/ð/ - this" },
  { value: "/s/", label: "/s/ - sun" },
  { value: "/z/", label: "/z/ - zoo" },
  { value: "/ʃ/", label: "/ʃ/ - ship" },
  { value: "/ʒ/", label: "/ʒ/ - measure" },
  { value: "/h/", label: "/h/ - hat" },
  { value: "/tʃ/", label: "/tʃ/ - chair" },
  { value: "/dʒ/", label: "/dʒ/ - jump" },
  { value: "/l/", label: "/l/ - leg" },
  { value: "/r/", label: "/r/ - red" },
  { value: "/j/", label: "/j/ - yes" },
  { value: "/w/", label: "/w/ - wet" },

  // English Vowels
  { value: "/i/", label: "/i/ - see" },
  { value: "/ɪ/", label: "/ɪ/ - sit" },
  { value: "/e/", label: "/e/ - say" },
  { value: "/ɛ/", label: "/ɛ/ - bed" },
  { value: "/æ/", label: "/æ/ - cat" },
  { value: "/ɑ/", label: "/ɑ/ - father" },
  { value: "/ɔ/", label: "/ɔ/ - saw" },
  { value: "/o/", label: "/o/ - go" },
  { value: "/ʊ/", label: "/ʊ/ - put" },
  { value: "/u/", label: "/u/ - too" },
  { value: "/ʌ/", label: "/ʌ/ - but" },
  { value: "/ə/", label: "/ə/ - about" },
  { value: "/eɪ/", label: "/eɪ/ - day" },
  { value: "/aɪ/", label: "/aɪ/ - my" },
  { value: "/ɔɪ/", label: "/ɔɪ/ - boy" },
  { value: "/aʊ/", label: "/aʊ/ - now" },
  { value: "/oʊ/", label: "/oʊ/ - go" },

  // Mandarin Consonants
  { value: "/p/", label: "/p/ - 波 (ㄅ)" },
  { value: "/pʰ/", label: "/pʰ/ - 坡 (ㄆ)" },
  { value: "/t/", label: "/t/ - 的 (ㄉ)" },
  { value: "/tʰ/", label: "/tʰ/ - 特 (ㄊ)" },
  { value: "/k/", label: "/k/ - 歌 (ㄍ)" },
  { value: "/kʰ/", label: "/kʰ/ - 科 (ㄎ)" },
  { value: "/ts/", label: "/ts/ - 資 (ㄗ)" },
  { value: "/tsʰ/", label: "/tsʰ/ - 雌 (ㄘ)" },
  { value: "/tɕ/", label: "/tɕ/ - 雞 (ㄐ)" },
  { value: "/tɕʰ/", label: "/tɕʰ/ - 欺 (ㄑ)" },
  { value: "/ʈʂ/", label: "/ʈʂ/ - 知 (ㄓ)" },
  { value: "/ʈʂʰ/", label: "/ʈʂʰ/ - 吃 (ㄔ)" },
  { value: "/f/", label: "/f/ - 非 (ㄈ)" },
  { value: "/s/", label: "/s/ - 思 (ㄙ)" },
  { value: "/ɕ/", label: "/ɕ/ - 西 (ㄒ)" },
  { value: "/ʂ/", label: "/ʂ/ - 師 (ㄕ)" },
  { value: "/x/", label: "/x/ - 喜 (ㄏ)" },
  { value: "/m/", label: "/m/ - 媽 (ㄇ)" },
  { value: "/n/", label: "/n/ - 拿 (ㄋ)" },
  { value: "/l/", label: "/l/ - 拉 (ㄌ)" },
  { value: "/ɻ/", label: "/ɻ/ - 日 (ㄖ)" },

  // Mandarin Vowels
  { value: "/i/", label: "/i/ - 一 (ㄧ)" },
  { value: "/y/", label: "/y/ - 魚 (ㄩ)" },
  { value: "/u/", label: "/u/ - 烏 (ㄨ)" },
  { value: "/ɤ/", label: "/ɤ/ - 餓 (ㄜ)" },
  { value: "/ə/", label: "/ə/ - 恩 (ㄣ)" },
  { value: "/a/", label: "/a/ - 啊 (ㄚ)" },
  { value: "/ai/", label: "/ai/ - 愛 (ㄞ)" },
  { value: "/ei/", label: "/ei/ - 誒 (ㄟ)" },
  { value: "/au/", label: "/au/ - 奧 (ㄠ)" },
  { value: "/ou/", label: "/ou/ - 歐 (ㄡ)" },
]

type CustomActivity = {
  value: string
  label: string
  isCustom: boolean
}

export type LogEntry = {
  id: string
  sound: string
  activity: string
  attempts: string
  correct: string
  notes: string
  timestamp: string
}

type LogEntryFormProps = {
  onSaveEntry: (entry: LogEntry) => void
  onRemove?: () => void
  isRemovable?: boolean
}

export default function LogEntryForm({ onSaveEntry, onRemove, isRemovable = false }: LogEntryFormProps) {
  const { t } = useLanguage()

  const [formData, setFormData] = useState({
    sound: "",
    activity: "Games",
    attempts: "",
    correct: "",
    notes: "",
  })

  const [customActivities, setCustomActivities] = useState<CustomActivity[]>([])
  const [playActivities, setPlayActivities] = useState(basePlayActivities)
  const [newActivity, setNewActivity] = useState("")
  const [editingActivity, setEditingActivity] = useState<CustomActivity | null>(null)
  const [isDialogOpen, setIsDialogOpen] = useState(false)

  // Load custom activities from localStorage on component mount
  useEffect(() => {
    const savedActivities = localStorage.getItem("customActivities")
    if (savedActivities) {
      const parsed = JSON.parse(savedActivities) as CustomActivity[]
      setCustomActivities(parsed)
      setPlayActivities([...basePlayActivities, ...parsed])
    }
  }, [])

  // Save custom activities to localStorage whenever they change
  useEffect(() => {
    if (customActivities.length > 0) {
      localStorage.setItem("customActivities", JSON.stringify(customActivities))
    }
  }, [customActivities])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { id, value } = e.target
    setFormData((prev) => ({ ...prev, [id]: value }))
  }

  const handleSelectChange = (value: string) => {
    setFormData((prev) => ({ ...prev, activity: value }))
  }

  const handleDownload = () => {
    downloadCSV(formData)
  }

  const handleAddCustomActivity = () => {
    if (!newActivity.trim()) return

    const customActivity: CustomActivity = {
      value: `custom-${Date.now()}`,
      label: newActivity,
      isCustom: true,
    }

    setCustomActivities([...customActivities, customActivity])
    setPlayActivities([...basePlayActivities, ...customActivities, customActivity])
    setNewActivity("")
    setIsDialogOpen(false)
  }

  const handleEditCustomActivity = () => {
    if (!editingActivity || !newActivity.trim()) return

    const updatedCustomActivities = customActivities.map((activity) =>
      activity.value === editingActivity.value ? { ...activity, label: newActivity } : activity,
    )

    setCustomActivities(updatedCustomActivities)
    setPlayActivities([...basePlayActivities, ...updatedCustomActivities])
    setNewActivity("")
    setEditingActivity(null)
    setIsDialogOpen(false)
  }

  const handleDeleteCustomActivity = (activityToDelete: CustomActivity) => {
    const updatedCustomActivities = customActivities.filter((activity) => activity.value !== activityToDelete.value)

    setCustomActivities(updatedCustomActivities)
    setPlayActivities([...basePlayActivities, ...updatedCustomActivities])

    // If the deleted activity was selected, reset to default
    if (formData.activity === activityToDelete.value) {
      setFormData((prev) => ({ ...prev, activity: "Games" }))
    }
  }

  const openEditDialog = (activity: CustomActivity) => {
    setEditingActivity(activity)
    setNewActivity(activity.label)
    setIsDialogOpen(true)
  }

  const handleSaveEntry = () => {
    const entry: LogEntry = {
      id: Date.now().toString(),
      ...formData,
      timestamp: new Date().toISOString(),
    }
    onSaveEntry(entry)
  }

  const handleClearEntry = () => {
    setFormData({
      sound: "",
      activity: "Games",
      attempts: "",
      correct: "",
      notes: "",
    })
  }

  return (
    <Card className="mb-6 border-[#1e3163]/20">
      <CardHeader className="flex flex-row items-center justify-between pb-2 bg-[#1e3163] text-white rounded-t-lg">
        <CardTitle className="text-xl">{t("card.soundEntry")}</CardTitle>
        {isRemovable && (
          <Button variant="ghost" size="icon" onClick={onRemove} className="h-8 w-8 text-white hover:bg-[#1e3163]/80">
            <X className="h-4 w-4" />
          </Button>
        )}
      </CardHeader>
      <CardContent className="pt-6">
        <div className="space-y-6">
          <div className="space-y-2">
            <Label htmlFor="sound" className="text-base text-[#1e3163]">
              🎯 {t("form.targetSound")}
            </Label>
            <Select
              value={formData.sound}
              onValueChange={(value) => setFormData((prev) => ({ ...prev, sound: value }))}
            >
              <SelectTrigger id="sound" className="text-base border-[#1e3163]/30 focus:ring-[#1e3163]/30">
                <SelectValue placeholder={t("placeholder.selectSound")} />
              </SelectTrigger>
              <SelectContent className="max-h-[300px]">
                {ipaSymbols.map((symbol) => (
                  <SelectItem key={symbol.value} value={symbol.value} className="text-base">
                    {symbol.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="activity" className="text-base text-[#1e3163]">
              🎲 {t("form.playActivity")}
            </Label>
            <div className="flex gap-2">
              <Select value={formData.activity} onValueChange={handleSelectChange} className="flex-1">
                <SelectTrigger id="activity" className="text-base border-[#1e3163]/30 focus:ring-[#1e3163]/30">
                  <SelectValue placeholder={t("placeholder.selectActivity")} />
                </SelectTrigger>
                <SelectContent>
                  {playActivities.map((activity) => (
                    <SelectItem
                      key={activity.value}
                      value={activity.value}
                      className="text-base flex justify-between items-center group"
                    >
                      {activity.label}
                      {"isCustom" in activity && activity.isCustom && (
                        <div className="ml-2 opacity-0 group-hover:opacity-100 flex">
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6"
                            onClick={(e) => {
                              e.stopPropagation()
                              openEditDialog(activity)
                            }}
                          >
                            <Pencil className="h-3 w-3" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="h-6 w-6 text-red-500"
                            onClick={(e) => {
                              e.stopPropagation()
                              handleDeleteCustomActivity(activity)
                            }}
                          >
                            <X className="h-3 w-3" />
                          </Button>
                        </div>
                      )}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
                <DialogTrigger asChild>
                  <Button variant="outline" size="icon" className="shrink-0 border-[#1e3163]/30">
                    <Plus className="h-4 w-4" />
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>{editingActivity ? t("button.editActivity") : t("button.addActivity")}</DialogTitle>
                  </DialogHeader>
                  <div className="py-4">
                    <Input
                      value={newActivity}
                      onChange={(e) => setNewActivity(e.target.value)}
                      placeholder={t("placeholder.enterActivity")}
                      className="text-base"
                    />
                  </div>
                  <DialogFooter>
                    <Button
                      onClick={editingActivity ? handleEditCustomActivity : handleAddCustomActivity}
                      disabled={!newActivity.trim()}
                      className="bg-[#1e3163] hover:bg-[#1e3163]/90"
                    >
                      {editingActivity ? t("button.update") : t("button.add")}
                    </Button>
                  </DialogFooter>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="attempts" className="text-base text-[#1e3163]">
                🔢 {t("form.trials")}
              </Label>
              <Input
                id="attempts"
                type="number"
                min="0"
                value={formData.attempts}
                onChange={handleChange}
                className="text-base border-[#1e3163]/30 focus:ring-[#1e3163]/30"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="correct" className="text-base text-[#1e3163]">
                ✅ {t("form.correct")}
              </Label>
              <Input
                id="correct"
                type="number"
                min="0"
                value={formData.correct}
                onChange={handleChange}
                className="text-base border-[#1e3163]/30 focus:ring-[#1e3163]/30"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="notes" className="text-base text-[#1e3163]">
              📝 {t("form.notes")}
            </Label>
            <Textarea
              id="notes"
              rows={4}
              value={formData.notes}
              onChange={handleChange}
              className="text-base resize-none border-[#1e3163]/30 focus:ring-[#1e3163]/30"
            />
          </div>
        </div>
      </CardContent>
      <CardFooter className="flex flex-wrap gap-2 bg-gray-50 rounded-b-lg pt-4">
        <Button onClick={handleSaveEntry} className="flex-1 bg-[#8ba446] hover:bg-[#8ba446]/90" variant="default">
          <Save className="mr-2 h-4 w-4" />
          {t("button.logEntry")}
        </Button>
        <Button onClick={handleClearEntry} className="flex-1" variant="outline">
          <Trash2 className="mr-2 h-4 w-4" />
          {t("button.clearEntry")}
        </Button>
      </CardFooter>
    </Card>
  )
}
